import { useEffect } from "react";
import { useState } from "react";
import axios from "axios";

let App = () => {
    let [users, setUsers] = useState([]);
    let [show, toggleShow ] = useState(true);
    let [user, setNewUser ] = useState({ title : "", firstname : "", lastname : "", city : "", power : "" })
    let [edit_user, updateUser ] = useState({ _id:"", title : "", firstname : "", lastname : "", city : "", power : "" })
    
    useEffect(()=>{
        refresh();
    },[]);

    let refresh = ()=>{
        axios.get("http://localhost:5050/data")
        .then(res => setUsers(res.data))
        .catch(err => console.log("Error ", err));
    }
    let addUserHandler = ()=>{
        axios.post("http://localhost:5050/data",user).then(res => {
            console.log( res.data.message );
            refresh();
        })
    }
    let editHandler = (evt) => {
        axios.get("http://localhost:5050/update/"+evt.target.getAttribute("data-uid"),user).then(res => {
            updateUser(res.data)
            // console.log(res)
            toggleShow(false)
        })
    };
    let updateSelectedUser = ()=>{
        axios.put("http://localhost:5050/update/"+edit_user._id, edit_user)
        .then(res => {
            console.log( res.data.message );
            refresh();
            toggleShow(true)
        })
        .catch(err => console.log("Error ", err))
    }
    let deleteHandler = (evt) => {
        axios.delete("http://localhost:5050/delete/"+evt.target.getAttribute("data-uid")).then(res => {
            console.log( res.data.message );
            refresh();
        } )
    };
    let changeHandler = (evt) => setNewUser({...user, [ evt.target.id ] : evt.target.value  })
    let updateHandler = (evt) => updateUser({...edit_user, [ evt.target.getAttribute("data-prop") ] : evt.target.value  })
    return <div className="container">
                <h1>User | CRUD Application</h1>
                { show && <div>
                    <h2>Create New User</h2>
                    <div className="mb-3">
                        <label htmlFor="title" className="form-label">User Title</label>
                        <input onChange={ changeHandler } value={ user.title } className="form-control" id="title"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="firstname" className="form-label">User First Name</label>
                        <input onChange={ changeHandler } value={ user.firstname } className="form-control" id="firstname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="lastname" className="form-label">User Last Name</label>
                        <input onChange={ changeHandler } value={ user.lastname } className="form-control" id="lastname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="city" className="form-label">User City</label>
                        <input onChange={ changeHandler } value={ user.city } className="form-control" id="city"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="power" className="form-label">User Power</label>
                        <input onChange={ changeHandler } value={ user.power } type="number" className="form-control" id="power"/>
                    </div>
                    <button onClick={ addUserHandler } type="submit" className="btn btn-primary">Submit</button>
                </div>}

                { !show && <div>
                    <h2>Update User</h2>
                    <div className="mb-3">
                        <label htmlFor="e_title" className="form-label">User Title</label>
                        <input data-prop="title" onChange={ updateHandler } value={ edit_user.title } className="form-control" id="e_title"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="e_firstname" className="form-label">User First Name</label>
                        <input data-prop="firstname" onChange={ updateHandler } value={ edit_user.firstname } className="form-control" id="e_firstname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="e_lastname" className="form-label">User Last Name</label>
                        <input data-prop="lastname" onChange={ updateHandler } value={ edit_user.lastname } className="form-control" id="e_lastname"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="e_city" className="form-label">User City</label>
                        <input data-prop="city" onChange={ updateHandler } value={ edit_user.city } className="form-control" id="e_city"/>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="e_power" className="form-label">User Power</label>
                        <input data-prop="power" onChange={ updateHandler } value={ edit_user.power } type="number" className="form-control" id="e_power"/>
                    </div>
                    <button onClick={ updateSelectedUser } type="submit" className="btn btn-primary">Update User Info</button>
                </div>}
                <hr />
                <table className="table table-hover">
                    <thead>
                        <tr>
                            <th>Sl #</th>
                            <th>Title</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>City</th>
                            <th>Power</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                {
                    // JSON.stringify( users )
                    users.map((val, idx) => <tr key={ val._id }>
                        <td>{ idx + 1 }</td>
                        <td>{ val.title }</td>
                        <td>{ val.firstname }</td>
                        <td>{ val.lastname }</td>
                        <td>{ val.city }</td>
                        <td>{ val.power }</td>
                        <td>
                            <button onClick={ editHandler } data-uid={val._id} className="btn btn-warning">Edit</button>
                        </td>
                        <td>
                            <button onClick={ deleteHandler } data-uid={val._id} className="btn btn-danger">Delete</button>
                        </td>
                    </tr>)
                }
                </tbody>
                </table>
                <hr />
        {/*             
                <p>{ JSON.stringify(user, null, 1 ) }</p>
                <p>Update User : { JSON.stringify(edit_user, null, 1 ) }</p> 
        */}
           </div>
}

export default App;


/* Server  : http://p.ip.fi/5KhK */
/* Client  : http://p.ip.fi/s9CM */