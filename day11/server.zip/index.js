let express = require("express");
let mongoose = require("mongoose");
let cors = require("cors");
//-------------------------------------
let app = express();
app
.use(cors())
.use(express.json());

//-------------------------------------
// configuration to connect to DB
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User",Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String,
    city : String,
    power : String
}));
let url = "put your database url here"
mongoose.connect(url)
.then(res => console.log("DB Connected"))
.catch(err => console.log("Error ", err))

//-------------------------------------
app.get("/data",(req, res)=> {
    User.find(function(dberr, dbres){
        res.send( dbres )
    })
} );
app.post("/data",(req, res)=> {
    let user = new User(req.body);
    user.save()
    .then(dbres => res.send({ message : "User Added", userTitle : req.body.title  }))
    .catch(dberr => console.log("Error ", dberr)) 
} );
app.delete("/delete/:uid",(req, res)=> {
    User.findByIdAndDelete({ _id: req.params.uid }, function(dberr, dbres){
        if(dberr){ console.log("Error ", dberr )}
        else{ res.send({ message : "User Deleted", userTitle : dbres.title }) }
        }) 
} );
app.get("/update/:uid",(req, res)=> {
    User.findById({_id : req.params.uid },function(dberr, dbres){
        res.send( dbres )
        // console.log(dbres)
        // console.log(arguments.length)
    })
} );
app.put("/update/:uid",(req, res)=> {
    User.findById({ _id : req.params.uid }, function(dberr, dbres){
        dbres.title = req.body.title;
        dbres.firstname = req.body.firstname;
        dbres.lastname = req.body.lastname;
        dbres.city = req.body.city;
        dbres.power = req.body.power;
        dbres.save().then(updateres => res.send({ message : "User Updated ", userTitle : dbres.title }))
       }) 
} );

// CREATE / from CRUD
// setTimeout(function(){
    /* 
    User.find(function(dberr, dbres){
        console.log(dbres);
    })
    */
   /* 
   let user = new User({
    title : "Superman",
    firstname : "Clark",
    lastname : "Kent",
    city : "Metropolis",
    power : "9"
   });
   user.save()
   .then(dbres => console.log("user added"))
   .catch(dberr => console.log("Error ", dberr)) 
   */
    /* 
   User.findById("638b6e7c73ce3123c66a1a76", function(dberr, dbres){
    dbres.power = 5
    dbres.save().then(updateres => console.log( "Updated "))
   }) 
   */
    /*   
    User.findByIdAndDelete({ _id: "638b6e7c73ce3123c66a1a76" }, function(dberr, dbres){
    if(dberr){ console.log("Error ", dberr )}
    else{ console.log("Deleted") }
    }) 
   */
// },2000)
// READ / from CRUD
// UPDATE / from CRUD
// DELETE / from CRUD



//-------------------------------------
app.listen(5050,"localhost",function(err){
    if(err){ console.log("Error ", err)}
    else{ console.log("Webserver is now live on localhost : 5050")}
})