let FunComp = () => {
    let message = "Welcome to your life | Function Component";
    return <h1>{ message }</h1>
} 

export default FunComp