import { Component } from "react";

class ClassComp extends Component{
    state = {
        message : "Welcome to your life | Class Component",
        avengers :  ['Ironman', 'Hulk', 'Thor', 'Spiderman', 'Dr Strange', "Spiderman"]
    }
    /* 
    constructor(){
        super();
        this.addVision = this.addVision.bind(this);
    } 
    */
    addVision = () => {
        console.log("was called on addVision", this.state.avengers.length);
        this.setState({
            avengers : [...this.state.avengers, 'vision']
        })
    }
    render(){
        // jsx
        console.log("was called on render",this.avengers);
        return <div>
                    <h1>{ 5+6 }</h1>
                    <h1>{ Math.random() }</h1>
                    <h1>{ this.state.message.toUpperCase() }</h1>
                    <ul>
                        <li>{ this.state.avengers[0] }</li>
                        <li>{ this.state.avengers[1] }</li>
                        <li>{ this.state.avengers[2] }</li>
                        <li>{ this.state.avengers[3] }</li>
                    </ul>
                    <ol>
                    {
                        this.state.avengers.map((val, idx) => <li key={idx}>{ val }</li> )
                    }
                    </ol>
                    <button onClick={ this.addVision }>Add Vision</button>
                    <button onClick={ this.addVision }>Add Vision</button>
                    <button onClick={ this.addVision }>Add Vision</button>
                    <button onClick={ this.addVision }>Add Vision</button>
                    <button onClick={ this.addVision }>Add Vision</button>
                    <button onClick={ this.addVision }>Add Vision</button>
                    <button onClick={ this.addVision }>Add Vision</button>
                    <button onClick={ this.addVision }>Add Vision</button>
                    {/* 
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button>
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button>
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button>
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button>
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button>
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button>
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button>
                    <button onClick={ this.addVision.bind(this) }>Add Vision</button> 
                    */}
               </div>
    }
} 

export default ClassComp;