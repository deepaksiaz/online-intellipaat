import React, { Component } from "react";

class FirstComp extends Component{
    num = React.createRef();
    state = {
        power : 0
    }
    increaseHandler = ()=>{
        this.setState({ power : this.state.power + 1 });
    }
    decreaseHandler = ()=>{
            this.setState({ power : this.state.power - 1 });
    }
    set10Handler = ()=>{
        this.setState({ power : 10 });
    }
    setPowerFromRange = (evt)=>{
        this.setState({ power : Number(evt.target.value) });
    }
    setPowerFromNumber = ()=>{
        this.setState({ power : Number(this.num.current.value) });
    }
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
                    <h2>Power is : { this.state.power }</h2>
                    <button onClick={ this.increaseHandler }>Increase Power</button>
                    <button onClick={ this.decreaseHandler }>Decrease Power</button>
                    <button onClick={ this.set10Handler }>Set Power to 10 </button>
                    <input value={this.state.power} onChange={ (event) => this.setPowerFromRange(event) } type="range" />
                    <br />
                    <input  ref={ this.num } type="number" />
                    {/*                 
                    <button 
                    onClick={()=> this.setPowerFromNumber(document.getElementById("num").value)}>
                        Update</button> 
                    */}
                    <button onClick={ this.setPowerFromNumber }> Update </button>
               </div>
    }
}

export default FirstComp;