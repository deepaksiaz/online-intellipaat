import { createRoot } from "react-dom/client";
import FirstComp from "./components/firstcomp";

createRoot(document.getElementById("root")).render(<FirstComp/>)