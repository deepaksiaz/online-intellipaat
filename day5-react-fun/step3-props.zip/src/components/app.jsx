import { Component } from "react";
import FirstComp from "./firstcomp";

class App extends Component{
    state = {
        power : 0
    }
    render(){
        return <div>
                  <button onClick={()=> this.setState({ power : this.state.power + 1 })}> Increase Power </button>
                   <FirstComp version={ 1001 } power={ this.state.power }>
                        <section>
                            <article>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore harum excepturi ipsa illo animi vero, autem atque, ratione incidunt aspernatur soluta eligendi neque. Blanditiis quos odit, laboriosam aperiam dolor iste?
                            </article>
                            <article>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore harum excepturi ipsa illo animi vero, autem atque, ratione incidunt aspernatur soluta eligendi neque. Blanditiis quos odit, laboriosam aperiam dolor iste?
                            </article>
                            <article>
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore harum excepturi ipsa illo animi vero, autem atque, ratione incidunt aspernatur soluta eligendi neque. Blanditiis quos odit, laboriosam aperiam dolor iste?
                            </article>
                        </section>
                        <button>Buy This</button>
                   </FirstComp>
               </div>
    }
}

export default App;