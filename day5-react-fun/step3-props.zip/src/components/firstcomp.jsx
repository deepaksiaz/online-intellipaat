import { Component } from "react";

class FirstComp extends Component{
    render(){
        return <div>
                    <h1>Title from First Component</h1>
                    <div>{ this.props.children }</div>
                    <div>{ this.props.version * 2 }</div>
                    <h3>{ this.props.power }</h3>
               </div>
    }
}

export default FirstComp;