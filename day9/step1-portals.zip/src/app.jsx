import { Component } from "react";
import PortalComp from "./components/portal";

class App extends Component{
    state = {
        show : false,
        message : "I shall be in the popup area"
    }
    togglePopup = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
                    { !this.state.show &&  <button onClick={ this.togglePopup }>Show Popup</button> }
                    { this.state.show && <PortalComp togglePopup={ this.togglePopup }>
                        <div>
                            <h2>{ this.state.message }</h2>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quia hic ex aliquam minima quidem, eum enim distinctio voluptas recusandae officia placeat, minus fuga, cupiditate commodi possimus. Ipsum architecto id enim.
                                Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi dolorem quibusdam magni velit beatae quod molestias, ducimus at quia, voluptas numquam facere blanditiis possimus et enim minima magnam eveniet facilis.
                                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nihil, error nemo recusandae iusto accusamus quas aperiam consequatur mollitia inventore quis vel maiores quo quam consequuntur rem fugiat dolores. Architecto, dolorem.
                            </p>
                            <button onClick={ this.togglePopup }>Close</button>
                        </div>
                    </PortalComp> }
               </div>
    }
};

export default App;


/* http://p.ip.fi/UEUO */