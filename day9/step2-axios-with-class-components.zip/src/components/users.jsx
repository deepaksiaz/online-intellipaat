import { Component } from "react";
class UsersComp extends Component{
    render(){
        return <div>
                
                    <table className="table table-striped table-hover">
                        <thead className="table-dark">
                            <tr>
                                <th>User ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>eMail</th>
                                <th>Avatar</th>
                            </tr>
                        </thead>
                        <tbody>
                        {
                            this.props.users.map(function(val){
                                return  <tr key={val.id}>
                                            <td>{ val.id }</td>
                                            <td>{ val.first_name }</td>
                                            <td>{ val.last_name }</td>
                                            <td>{ val.email }</td>
                                            <td>
                                                <img width="60" src={ val.avatar } alt={ val.first_name } />
                                            </td>
                                        </tr>
                            })
                        }
                        </tbody>
                        </table>
               </div>
    }
}

export default UsersComp;