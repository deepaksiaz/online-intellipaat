import { Component } from "react";
class HeaderComp extends Component{   
    render(){
        return <div className="mb-3"> 
                <ul className="nav">
                        { this.props.users.map(function(val){
                                return <li className="nav-item">  <a className="nav-link" href="">{ val.first_name }</a> </li>
                            })
                        }
                </ul>
               </div>
    }
}

export default HeaderComp;