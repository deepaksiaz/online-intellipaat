import { Component } from "react";
import HeaderComp from "./components/header";
import UsersComp from "./components/users";
import axios from "axios";

class App extends Component{
    state = {
        users : []
    }
    
   componentDidMount(){
        axios.get("https://reqres.in/api/users?page=1")
        .then(res => this.setState({ users : res.data.data }) )
        .catch(error => console.log("Error ", error))
    } 

   changeHandler = (evt)=>{
        axios.get(evt.target.value)
        .then(res => this.setState({ users : res.data.data }) )
        .catch(error => console.log("Error ", error))
   }
    render(){
        return <div className="container">
                    <h1>Users List</h1>
                    <select className="form-select mb-3" onChange={ this.changeHandler }>
                        <option selected value="https://reqres.in/api/users?page=1">Page 1</option>
                        <option  value="https://reqres.in/api/users?page=2">Page 2</option>
                    </select>
                    <hr />
                    <HeaderComp users={ this.state.users }/>
                    <UsersComp users={ this.state.users }/>
               </div>
    }
}

export default App;

/* http://p.ip.fi/OQSe */

/* http://p.ip.fi/daZh */


/* http://p.ip.fi/6nkl */