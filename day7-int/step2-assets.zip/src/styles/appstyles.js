export let appstyleBlock = { 
    backgroundColor : "#344E41", 
    color : "#DAD7CD", 
    padding : "20px", 
    margin : "10px", 
    width : "600px", 
    textAlign:"justify", 
    fontFamily : "sans-serif" 
};