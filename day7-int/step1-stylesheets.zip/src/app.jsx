import { Component } from "react";
import { appstyleBlock } from "./styles/appstyles";
import client from "./styles/client.module.css";
import "./styles/mystyle.css";

class App extends Component{
    render(){
        let articleStyle = appstyleBlock
        return <div className="container">
                    <h1>Style Sheets</h1>
                    <hr />
                    {/* inline style */}
                    <article style={ {  backgroundColor : "#344E41",  color : "#DAD7CD", padding : "20px",  margin : "10px",  width : "600px",  textAlign:"justify",  fontFamily : "sans-serif" 
                                    } }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus harum mollitia placeat assumenda laborum! Optio ducimus commodi totam eveniet quo ratione velit aliquam cupiditate! Quis dolor eum illum officiis inventore!
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam obcaecati iure eaque magni cupiditate repudiandae aliquid veritatis, reprehenderit vero fugit, aperiam impedit porro voluptatum maxime aspernatur, nobis libero laborum quasi.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores est in quis excepturi nam animi explicabo fugiat necessitatibus facilis dolorem ipsum incidunt, eligendi unde placeat magnam odit quidem pariatur porro!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, libero maxime dolor sapiente voluptate accusamus, aspernatur doloribus tempora quis quas nam autem distinctio ex explicabo pariatur? Vero dolorem ab ipsum.
                    </article>
                    {/* external style file */}
                    <article style={ articleStyle }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus harum mollitia placeat assumenda laborum! Optio ducimus commodi totam eveniet quo ratione velit aliquam cupiditate! Quis dolor eum illum officiis inventore!
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam obcaecati iure eaque magni cupiditate repudiandae aliquid veritatis, reprehenderit vero fugit, aperiam impedit porro voluptatum maxime aspernatur, nobis libero laborum quasi.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores est in quis excepturi nam animi explicabo fugiat necessitatibus facilis dolorem ipsum incidunt, eligendi unde placeat magnam odit quidem pariatur porro!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, libero maxime dolor sapiente voluptate accusamus, aspernatur doloribus tempora quis quas nam autem distinctio ex explicabo pariatur? Vero dolorem ab ipsum.
                    </article>
                    {/* external style file with custamisation */}
                    <article style={ {...articleStyle, backgroundColor : "#bc4749"} }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus harum mollitia placeat assumenda laborum! Optio ducimus commodi totam eveniet quo ratione velit aliquam cupiditate! Quis dolor eum illum officiis inventore!
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam obcaecati iure eaque magni cupiditate repudiandae aliquid veritatis, reprehenderit vero fugit, aperiam impedit porro voluptatum maxime aspernatur, nobis libero laborum quasi.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores est in quis excepturi nam animi explicabo fugiat necessitatibus facilis dolorem ipsum incidunt, eligendi unde placeat magnam odit quidem pariatur porro!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, libero maxime dolor sapiente voluptate accusamus, aspernatur doloribus tempora quis quas nam autem distinctio ex explicabo pariatur? Vero dolorem ab ipsum.
                    </article>
                    {/* external css file */}
                    <article className="box">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus harum mollitia placeat assumenda laborum! Optio ducimus commodi totam eveniet quo ratione velit aliquam cupiditate! Quis dolor eum illum officiis inventore!
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam obcaecati iure eaque magni cupiditate repudiandae aliquid veritatis, reprehenderit vero fugit, aperiam impedit porro voluptatum maxime aspernatur, nobis libero laborum quasi.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores est in quis excepturi nam animi explicabo fugiat necessitatibus facilis dolorem ipsum incidunt, eligendi unde placeat magnam odit quidem pariatur porro!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, libero maxime dolor sapiente voluptate accusamus, aspernatur doloribus tempora quis quas nam autem distinctio ex explicabo pariatur? Vero dolorem ab ipsum.
                    </article>
                    <article className={ client.box }>
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus harum mollitia placeat assumenda laborum! Optio ducimus commodi totam eveniet quo ratione velit aliquam cupiditate! Quis dolor eum illum officiis inventore!
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam obcaecati iure eaque magni cupiditate repudiandae aliquid veritatis, reprehenderit vero fugit, aperiam impedit porro voluptatum maxime aspernatur, nobis libero laborum quasi.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores est in quis excepturi nam animi explicabo fugiat necessitatibus facilis dolorem ipsum incidunt, eligendi unde placeat magnam odit quidem pariatur porro!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, libero maxime dolor sapiente voluptate accusamus, aspernatur doloribus tempora quis quas nam autem distinctio ex explicabo pariatur? Vero dolorem ab ipsum.
                    </article>
                    <article className="bg-primary text-white">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus harum mollitia placeat assumenda laborum! Optio ducimus commodi totam eveniet quo ratione velit aliquam cupiditate! Quis dolor eum illum officiis inventore!
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam obcaecati iure eaque magni cupiditate repudiandae aliquid veritatis, reprehenderit vero fugit, aperiam impedit porro voluptatum maxime aspernatur, nobis libero laborum quasi.
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Maiores est in quis excepturi nam animi explicabo fugiat necessitatibus facilis dolorem ipsum incidunt, eligendi unde placeat magnam odit quidem pariatur porro!
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aliquid, libero maxime dolor sapiente voluptate accusamus, aspernatur doloribus tempora quis quas nam autem distinctio ex explicabo pariatur? Vero dolorem ab ipsum.
                    </article>
               </div>
    }
}

export default App;

/* https://coolors.co/ */