let FunctionChildComp  = (props)=> {
        console.log("Function Based Component was rendered")
        return <div>
                    <h1>Function Based Component</h1>
                    <h2>Version is : { props.version }</h2>
                    <h2>Power is : { props.power }</h2>
                    <h2>Shows is : { props.shows }</h2>
               </div>
}

export default FunctionChildComp;
