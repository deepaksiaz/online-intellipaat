import { memo } from "react";
let FunctionMemoChildComp  = (props)=> {
    console.log("Function Based Memo Component was rendered")
    return <div>
                <h1>Function Based Memo Component</h1>
                <h2>Version is : { props.version }</h2>
                <h2>Power is : { props.power }</h2>
                <h2>Shows is : { props.shows }</h2>
           </div>
}

export default memo( FunctionMemoChildComp );
