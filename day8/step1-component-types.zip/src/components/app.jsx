import { Component } from "react";
import ClassChildComp from "./classChildComp";
import ClassPureComp from "./classPureComp";
import FunctionChildComp from "./funComp";
import FunctionMemoChildComp from "./funmemocomp";

class App extends Component{
    state = {
        version : 0,
        power : 0,
        heroes : {  movies : [ { moviename : "Batman Begins", show : 5 }, { moviename : "Dark Knight", show : 6 } ] }
    }
    render(){
        return <div>
            <h1>Welcome to your life</h1>
            <h2>Version is : { this.state.version }</h2>
            <h2>Power is : { this.state.power }</h2>
            <button onClick={ ()=> this.setState({ power : this.state.power + 1 })}>Increase Power</button>
            <button onClick={ ()=> this.setState({ version : this.state.version + 1 })}>Increase Version</button>
            <button onClick={ ()=> this.setState({ power : 10 })}>Set Power to 10</button>
            <button onClick={ ()=> this.setState({ heroes : {movies : [ { show : this.state.heroes.movies[0].show + 1 }]} })}>Increase Show CountPower</button>
            <hr />
            <ClassChildComp version={ this.state.version } power={ this.state.power } shows={ this.state.heroes.movies[0].show }/>
            <ClassPureComp version={ this.state.version } power={ this.state.power } shows={ this.state.heroes.movies[0].show }/>
            <FunctionChildComp version={ this.state.version } power={ this.state.power } shows={ this.state.heroes.movies[0].show }/>
            <FunctionMemoChildComp version={ this.state.version } power={ this.state.power } shows={ this.state.heroes.movies[0].show }/>
        </div>
    }
}

export default App;

// https://tooncrush.com/data.zip