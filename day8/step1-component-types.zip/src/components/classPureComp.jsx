import { PureComponent } from "react";

class ClassPureComp extends PureComponent{  
    render(){
        console.log("Class Pure Component was rendered")
        return <div>
                    <h1>Class Based Pure Component</h1>
                    <h2>Version is : { this.props.version }</h2>
                    <h2>Power is : { this.props.power }</h2>
                    <h2>Shows is : { this.props.shows }</h2>
               </div>
    }
}

export default ClassPureComp;
