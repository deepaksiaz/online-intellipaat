import { Component } from "react";

class ClassChildComp extends Component{
    shouldComponentUpdate(currentProp){
        if(currentProp.power === this.props.power ){
            return false
        }else{
            return true
        }
    }
    render(){
        console.log("Class Component was rendered");
        return <div>
                    <h1>Class Based Component</h1>
                    <h2>Version is : { this.props.version }</h2>
                    <h2>Power is : { this.props.power }</h2>
                    <h2>Shows is : { this.props.shows }</h2>
               </div>
    }
}

export default ClassChildComp;

/* 
class 
    Component
    Pure Component
function 
    regular function component 
    memo component
Higher order Component
*/