import { createRoot } from "react-dom/client";
import App from "./components/app";

createRoot(document.getElementById("root")).render(<App/>)

/*
Higher Order Functions
is a function that takes a functiona and returns a function 

Higher Order Component
is a function that takes a component and returns a component 
*/

/* http://p.ip.fi/7L10 */