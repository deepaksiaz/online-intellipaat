import { Component } from "react";
import DuplicatePowerComp from "./duplicatePowerComp";
import PowerComp from "./powercomp";

class App extends Component{
    render(){
        return <div>
                 <h1>Using Higher Order Components</h1>
                 <PowerComp title="Power Component"/>
                 <DuplicatePowerComp title="Duplicate Power Component"/>
               </div>
    }
}

export default App;