import { Component } from "react";

let WithPower = (OriginalComp)=>{
    
    class TempComp extends Component{
        state = {
            power : 0
        }
        increasePower = ()=>{
            this.setState({
                power : this.state.power + 1
            })
        }
        decreasePower = ()=>{
            this.setState({
                power : this.state.power - 1
            })
        }
        render(){
            return <OriginalComp { ...this.props } increasePower={this.increasePower} decreasePower={ this.decreasePower } power={this.state.power} version="101"/>
        }
    }

    return TempComp;
}

export default WithPower;