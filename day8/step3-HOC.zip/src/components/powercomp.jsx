import { Component } from "react";
import WithPower from "./withpower";

class PowerComp extends Component{
    
    render(){
        return <div>
                    <h1>Power Component : { this.props.power }</h1>
                    <h2>Version is { this.props.version }</h2>
                    <h2>{ this.props.title }</h2>
                    <button onClick={ this.props.increasePower }>Increase Power</button>
                    <button onClick={ this.props.decreasePower }>Decrease Power</button>
                </div>
    }
}

export default WithPower( PowerComp );