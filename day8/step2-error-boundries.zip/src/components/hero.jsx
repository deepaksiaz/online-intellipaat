import { Component } from "react";

class HeroComp extends Component{
    render(){
       if(this.props.power < 5){
            throw new Error("Hero's power is less than 5 so he / she can not participate in the battle")
       }else{
        return <div>
                    <h1>Hero Component Power is { this.props.power }</h1>
               </div>
       }
    }
}

export default HeroComp;