import { Component } from "react";
import Heroes from "./heroes";

class App extends Component{
    render(){
        return <div>
                    <h1>Main Application</h1>
                    <hr />
                    <Heroes/>
                </div>
    }
}

export default App;

/* http://p.ip.fi/b8oJ */