import { Component } from "react";

class Ironman extends Component{
    render(){
        return <div>
                    <h1>Ironman Component</h1>
                </div>
    }
}

export default Ironman;