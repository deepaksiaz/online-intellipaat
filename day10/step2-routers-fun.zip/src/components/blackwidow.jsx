import { Component } from "react";

class BlackWidow extends Component{
    render(){
        return <div>
                    <h1>BlackWidow Component</h1>
                </div>
    }
}

export default BlackWidow;