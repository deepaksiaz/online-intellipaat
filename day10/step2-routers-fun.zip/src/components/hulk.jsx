import { Component } from "react";

class Hulk extends Component{
    render(){
        return <div>
                    <h1>Hulk Component</h1>
                </div>
    }
}

export default Hulk;