import React, { Component, Suspense } from "react";
import { BrowserRouter, Link, NavLink, Route, Routes } from "react-router-dom";
import Home from "./components/home";
import "./app.routelinks.css";
/* 
import BlackWidow from "./components/blackwidow";
import Hulk from "./components/hulk";
import Ironman from "./components/ironman";
import NotFound from "./components/notfound";
import Thor from "./components/thor"; 
*/

let BlackWidow = React.lazy( () => import("./components/blackwidow"))
let Hulk = React.lazy( () => import("./components/hulk"))
let Ironman = React.lazy( () => import("./components/ironman"))
let NotFound = React.lazy( () => import("./components/notfound"))
let Thor = React.lazy( () => import("./components/thor"))


class App extends Component{
    state = {
        quantity : 0
    }
    render(){
        let activeFun = ({isActive})=> isActive ? 'box' : 'link';
        return <div>
                    <h1>Welcome to your life</h1>
                    <h3>Quantity is { this.state.quantity }</h3>
                    <button onClick={()=> this.setState({ quantity : Math.round( Math.random() * 500 )})}>Random Quantity for Hulk</button>
                    <BrowserRouter>
                        <ul>
                            {/* <li> <NavLink className={({isActive})=> isActive ? 'box' : null} to={"scarlet"}>Scarlet</NavLink> </li> */}
                            <li> <NavLink className={ activeFun } to={""}>Home</NavLink> </li>
                            <li> <NavLink className={ activeFun } to={"ironman"}>Ironman</NavLink> </li>
                            <li> <NavLink className={ activeFun } to={"hulk/"+this.state.quantity}>Hulk with Quantity</NavLink> </li>
                            <li> <NavLink className={ activeFun } to={"thor"}>Thor</NavLink> </li>
                            <li> <NavLink className={ activeFun } to={"blackwidow"}>Black Widow</NavLink> </li>
                            <li> <NavLink className={ activeFun } to={"scarlet"}>Scarlet</NavLink> </li>
                        </ul> 
                        <Routes>
                            <Route path="/" element={<Home/>} />
                            <Route path="ironman" element={<Suspense fallback={<>Loading Ironman... </>}><Ironman/></Suspense>} />
                            <Route path="hulk/:qty" element={<Suspense fallback={<>Loading Hulk... </>}><Hulk/> </Suspense>} />
                            <Route path="thor" element={<Suspense fallback={<>Loading Thor... </>}> <Thor/></Suspense>} />
                            <Route path="blackwidow" element={<Suspense fallback={<>Loading Black Widow... </>}> <BlackWidow/></Suspense>} />
                            <Route path="*" element={<Suspense fallback={<>Loading Not Found... </>}> <NotFound/></Suspense>} />
                        </Routes>
                    </BrowserRouter>
               </div>
    }
}

export default App;

/* http://p.ip.fi/DbSI  */