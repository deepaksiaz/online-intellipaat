import { Component } from "react";

class Thor extends Component{
    render(){
        return <div>
                    <h1>Thor Component</h1>
                </div>
    }
}

export default Thor;