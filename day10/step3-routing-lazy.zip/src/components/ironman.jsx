import { useNavigate } from "react-router-dom";

let Ironman = ()=>{
    let black = useNavigate()
    return <div>
                <h1>Ironman Component</h1>
                <button onClick={ ()=> black('/blackwidow', { replace : true }) }>Black Widow</button>
            </div>
}

export default Ironman;