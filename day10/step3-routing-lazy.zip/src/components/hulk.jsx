import { useParams } from "react-router-dom";

let Hulk = ()=>{
    let params = useParams();
    return <div>
                <h1>Hulk Component</h1>
                <h2>Quantity : { params.qty }</h2>
            </div>
}

export default Hulk;