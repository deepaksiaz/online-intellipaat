import { Component } from "react";
import ChildComp from "./child";

class ParentComp extends Component{
    render(){
        return <div style={ { border: "2px solid grey", padding : "10px", margin : "10px"} }>
            <h1>Parent Component</h1>
            <ChildComp/>
        </div>
    }
}

export default ParentComp;