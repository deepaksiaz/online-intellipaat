import { useContext } from "react";
import { FamilyContext } from "../contexts/familyContext";

let ChildComp = ()=>{
    let val = useContext(FamilyContext);
    return <div style={ { border: "2px solid grey", padding : "10px", margin : "10px"} }>
                <h1>Child Component</h1>
                <p>{ val }</p>
                <p>{ (val +"").toUpperCase() }</p>
                <p>{ val }</p>
                <p>{ val }</p>
                {/*  
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer> 
                */}
            </div>
}

export default ChildComp;

/* http://p.ip.fi/BteE */