import React from "react";

export let ParentContext = React.createContext();