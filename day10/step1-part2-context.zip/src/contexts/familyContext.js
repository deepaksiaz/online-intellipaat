import React from "react";

export let FamilyContext = React.createContext();

/* 
let Provider = FamilyContext.Provider;
let Consumer = FamilyContext.Consumer; 
*/

