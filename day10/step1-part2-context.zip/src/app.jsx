import { Component } from "react";
import GrandParentComp from "./components/grandparent";

class App extends Component{
    render(){
        return <div>
            <h1>Welcome to your life</h1>
            <GrandParentComp/>
        </div>
    }
}

export default App;

/* http://p.ip.fi/uWGN */