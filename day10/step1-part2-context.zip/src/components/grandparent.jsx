import React, { Component } from "react";
import { FamilyContext } from "../contexts/familyContext";
import CousinComp from "./cousin";
import ParentComp from "./parent";

class GrandParentComp extends Component{
    messageInput = React.createRef();
    state  = {
        message : "grandparent's message"
    }
    changeMessageHandler = ()=>{
        this.setState({
            message : this.messageInput.current.value
        })
    }
    render(){
        return <div style={ { border: "2px solid grey", padding : "10px", margin : "10px"} }>
                    <h1>Grand Parent Component</h1>
                    <h2>Message is : { this.state.message }</h2>
                    <input ref={ this.messageInput } type="text" />
                    <button onClick={ this.changeMessageHandler }>Change Message</button>
                    <FamilyContext.Provider value={ this.state.message }>
                        <ParentComp/>
                        <CousinComp/>
                    </FamilyContext.Provider>
                </div>
    }
}

export default GrandParentComp;