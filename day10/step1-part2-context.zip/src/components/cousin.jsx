import { useContext } from "react";
import { FamilyContext } from "../contexts/familyContext";

let CousinComp = () => {
    let val = useContext(FamilyContext);
    return <div style={ { border: "2px solid grey", padding : "10px", margin : "10px"} }>
                <h1>Cousin Component</h1>
                <h2>Message is : { val }</h2>
           </div>
}

export default CousinComp;