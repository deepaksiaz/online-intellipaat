import { useContext } from "react";
import { FamilyContext } from "../contexts/familyContext";
import { ParentContext } from "../contexts/parentContext";

let ChildComp = ()=>{
    let val = useContext(FamilyContext);
    let parentVal = useContext(ParentContext);
    return <div style={ { border: "2px solid grey", padding : "10px", margin : "10px"} }>
                <h1>Child Component</h1>
                <p>{ val }</p>
                <p>{ (val +"").toUpperCase() }</p>
                <p>{ val }</p>
                <p>{ val }</p>
                <p>Parent's Version : { parentVal }</p>
                {/*  
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer>
                <FamilyContext.Consumer>{(val)=><p>{ val }</p>}</FamilyContext.Consumer> 
                */}
            </div>
}

export default ChildComp;

/* http://p.ip.fi/BteE */