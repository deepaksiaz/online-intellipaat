import { Component } from "react";
import { ParentContext } from "../contexts/parentContext";
import ChildComp from "./child";

class ParentComp extends Component{
    render(){
        return <div style={ { border: "2px solid grey", padding : "10px", margin : "10px"} }>
            <h1>Parent Component</h1>
            <ParentContext.Provider value={1001} >
                <ChildComp/>
            </ParentContext.Provider>
        </div>
    }
}

export default ParentComp;