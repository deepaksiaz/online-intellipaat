import { Component } from "react";
import { Provider } from "react-redux";
import AvengersComp from "./components/avengers";
import store from "./redux/store"

class App extends Component{
    render(){
        return <div>
                    <h1>React and Redux Example</h1>
                    <Provider store={ store }>
                        <AvengersComp/>
                    </Provider>
               </div>
    }
}

export default App;