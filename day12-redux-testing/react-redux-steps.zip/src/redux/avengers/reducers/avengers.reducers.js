import { ADDHERO, REMOVEHERO } from "../actiontypes/avengers.types"

const initialHeroState = {
    numberOfAvengers : 0
}
const heroReducer = (state = initialHeroState, action  )=>{
    switch(action.type){
        case ADDHERO : return { ...state, numberOfAvengers : state.numberOfAvengers + 1 }
        case REMOVEHERO : return { ...state, numberOfAvengers : state.numberOfAvengers - 1 }
        default : return state
    }
}

export { heroReducer }