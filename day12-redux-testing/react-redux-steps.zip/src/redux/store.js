import { legacy_createStore as createStore } from "redux";
import { heroReducer } from "./avengers/reducers/avengers.reducers";
const store = createStore(heroReducer);

export default store;