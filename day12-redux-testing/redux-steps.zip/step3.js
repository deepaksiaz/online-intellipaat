let redux = require("redux");
let createStore = redux.legacy_createStore;
// action
const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO";
const SETHERO = "SETHERO";

// action creator
let addhero = ()=>{
    return {
        type : ADDHERO
    }
}
let removehero = ()=>{
    return {
        type : REMOVEHERO
    }
}
let sethero = (num)=>{
    return {
        type : SETHERO,
        payload : num
    }
}

// initial state
let initialState = {
    numberOfAvengers : 0
}

// reducer
let reducer = function(state = initialState, action){
    switch(action.type){
        case ADDHERO : return { numberOfAvengers :  state.numberOfAvengers + 1 }
        case REMOVEHERO : return { numberOfAvengers :  state.numberOfAvengers - 1 }
        case SETHERO : return { numberOfAvengers :  action.payload }
        default : return state
    }
}

// store
let store = createStore(reducer);
console.log(store.getState());

// subscribe / unsubscribe
store.subscribe(function(){
    console.log("changes on store");
    console.log(store.getState());
});

store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(sethero(5));
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(removehero());
store.dispatch(sethero(20));
store.dispatch(removehero());
store.dispatch(addhero());


/* 
npm init -y 
npm i redux 
*/