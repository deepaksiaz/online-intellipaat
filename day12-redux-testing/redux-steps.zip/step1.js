let redux = require("redux");
let createStore = redux.createStore;
// action
const ADDHERO = "ADDHERO";

// action creator
let addhero = ()=>{
    return {
        type : ADDHERO
    }
}

// initial state
let initialState = {
    numberOfAvengers : 0
}

// reducer
let reducer = function(state = initialState, action){
    switch(action.type){
        case ADDHERO : return { numberOfAvengers :  state.numberOfAvengers + 1 }
        default : return state
    }
}

// store
let store = createStore(reducer);
console.log(store.getState());

// subscribe / unsubscribe
store.subscribe(function(){
    console.log("changes on store");
    console.log(store.getState());
});

store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
