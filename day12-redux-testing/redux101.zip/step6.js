let redux = require("redux");
let createStore = redux.legacy_createStore;
let combineReducers = redux.combineReducers;
let bindActionCreators = redux.bindActionCreators;
// action
const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO";
const SETHERO = "SETHERO";

const ADDMOVIE = "ADDMOVIE";
const REMOVEMOVIE = "REMOVEMOVIE";
const SETMOVIE = "SETMOVIE";

// action creator
let addhero = ()=>{
    return {
        type : ADDHERO
    }
}
let removehero = ()=>{
    return {
        type : REMOVEHERO
    }
}
let sethero = (num)=>{
    return {
        type : SETHERO,
        payload : num
    }
}
// action creator
let addmovie = ()=>{
    return {
        type : ADDMOVIE
    }
}
let removemovie = ()=>{
    return {
        type : REMOVEMOVIE
    }
}
let setmovie = (num)=>{
    return {
        type : SETMOVIE,
        payload : num
    }
}

// initial state
let initialHeroState = {
    numberOfAvengers : 0
}
let initialMovieState = {
    numberOfMovies : 0
}

// reducer
let heroReducer = function(state = initialHeroState, action){
    switch(action.type){
        case ADDHERO : return {...state, numberOfAvengers :  state.numberOfAvengers + 1 }
        case REMOVEHERO : return {...state, numberOfAvengers :  state.numberOfAvengers - 1 }
        case SETHERO : return {...state, numberOfAvengers :  action.payload }
        default : return state
    }
}
let movieReducer = function(state = initialMovieState, action){
    switch(action.type){
        case ADDMOVIE : return {...state, numberOfMovies :  state.numberOfMovies + 1 }
        case REMOVEMOVIE : return {...state, numberOfMovies :  state.numberOfMovies - 1 }
        case SETMOVIE : return {...state, numberOfMovies :  action.payload }
        default : return state
    }
}

// combineReducers
let rootReducers = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})

// store
let store = createStore(rootReducers);
console.log(store.getState());

// subscribe / unsubscribe
store.subscribe(function(){
    console.log("changes on store");
    console.log(store.getState());
});

/* 
store.dispatch(addhero());
store.dispatch(addmovie());
store.dispatch(addmovie());
store.dispatch(addhero());
store.dispatch(sethero(5));
store.dispatch(setmovie(5));
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(removemovie());
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(removehero());
store.dispatch(sethero(20));
store.dispatch(removehero());
store.dispatch(addhero());
 */

let action = bindActionCreators({addhero, removehero, sethero, addmovie, removemovie, setmovie}, store.dispatch);

action.addhero();
action.removehero();
action.sethero(5);
action.addmovie();
action.removemovie();
action.setmovie(10);