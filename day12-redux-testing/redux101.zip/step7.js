let redux = require("redux");
let reduxThunk = require("redux-thunk").default;
let axios = require("axios");

let createStore = redux.legacy_createStore;
let applyMiddleware = redux.applyMiddleware;

// action
let AXIOS_USERS_REQUEST = "AXIOS_USERS_REQUEST";
let AXIOS_USERS_SUCCESS = "AXIOS_USERS_SUCCESS";
let AXIOS_USERS_ERROR = "AXIOS_USERS_ERROR";

// action creator
let fetchUsers = () => {
    return {
         type : AXIOS_USERS_REQUEST
    }
}
let fetchUsersSuccess = (users) => {
    return {
         type : AXIOS_USERS_SUCCESS,
         payload : users
    }
}
let fetchUsersError = (err) => {
    return {
         type : AXIOS_USERS_ERROR,
         payload : err
    }
}
// initial state
const initialState = {
    loading : false,
    users : [],
    error : ""
}
// reducer
const reducer = (state = initialState, action)=>{
    switch(action.type){
        case AXIOS_USERS_REQUEST : return { ...state, loading : true, users : [], error : ""}
        case AXIOS_USERS_SUCCESS : return { ...state, loading : false, users : action.payload, error : ""}
        case AXIOS_USERS_ERROR : return { ...state, loading : false, users : [], error : action.payload }
        default : return state
    }
};

let thunkFetchUsers = ()=>{
    return function(dispatch){
        dispatch( fetchUsers() )
    }
}
let thunkAjaxUsers = ()=>{
    return function(dispatch){
        axios
        .get("https://reqres.in/api/users?page=2")
        .then( res => dispatch( fetchUsersSuccess( res.data.data )) )
        .catch( err => dispatch( fetchUsersError( err )) )
    }
}
// store
let store = createStore(reducer,applyMiddleware(reduxThunk));
console.log( store.getState() );
// subscribe / unsubscribe
store.subscribe( ()=> console.log(store.getState() ) );

store.dispatch( thunkFetchUsers() );

store.dispatch( thunkAjaxUsers() );