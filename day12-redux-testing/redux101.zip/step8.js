const axios = require("axios");
const redux = require("redux");
const thunkMiddleware = require("redux-thunk").default;

// ----------------------------------------------------

const createStore = redux.legacy_createStore;
const applyMiddleware = redux.applyMiddleware;

// Action Types
const AXIOS_USER_REQUEST = "AXIOS_USER_REQUEST";
const AXIOS_USER_SUCCESS = "AXIOS_USER_SUCCESS";
const AXIOS_USER_ERROR = "AXIOS_USER_ERROR";

// Action Creators
let fetchUsers = ()=>{
    return {
        type : AXIOS_USER_REQUEST
    }
}
let fetchUserSuccess = (users)=>{
    return {
        type : AXIOS_USER_SUCCESS,
        payload : users
    }
}
let fetchUserError = (error)=>{
    return {
        type : AXIOS_USER_ERROR,
        payload : error
    }
}
// Default state
const initalState = {
    loading : false,
    users : [],
    error : ''
}
// Reducers
const reducer = (state = initalState, action) =>{
    switch(action.type){
        case AXIOS_USER_REQUEST : return {
            ...state,
            loading : true
        }
        case AXIOS_USER_SUCCESS : return {
            ...state,
            loading : false,
            users : action.payload,
            error : ''
        }
        case AXIOS_USER_ERROR : return {
            ...state,
            loading : false,
            users : [],
            error : action.payload
        }
        default : return state
    }
}

// configure action creators from middlewares

let thunkFetchUsers = ()=>{
    return function(dispatch){
        dispatch( fetchUsers() )
    }
}

let thunkAjaxFetchUsers = ()=>{
    return function(dispatch){
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then(resonse => dispatch( fetchUserSuccess(resonse.data) ))
        .catch(error => dispatch( fetchUserError( error )) )
    }
}

// Store
const store = createStore( reducer, applyMiddleware( thunkMiddleware ) );

store.subscribe(()=>{
    console.log(store.getState());
})

// subscribe and unsubscribe to store changes

store.dispatch( thunkFetchUsers() );
store.dispatch( thunkAjaxFetchUsers() );

/* setTimeout(()=>{
    store.dispatch( thunkAjaxFetchUsers() );
},2000); */