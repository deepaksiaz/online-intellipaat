import { Component } from "react";
import { connect } from "react-redux";
import { addHero, removeHero } from "../redux/avengers/actioncreators/avengers.action.creators";

class AvengersComp extends Component{
    render(){
        return <div>
                    <h1>Avengers</h1>
                    <h2>Number of Avengers : { this.props.numberOfAvengers }</h2>
                    <button onClick={ this.props.addHero }>Add Avenger</button>
                    <button onClick={ this.props.removeHero }>Remove Avenger</button>
               </div>
    }
}
const mapStateToProps = (state) => {
    return {
        numberOfAvengers : state.numberOfAvengers
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        addHero : ()=> dispatch( addHero() ),
        removeHero : ()=> dispatch( removeHero() ),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(AvengersComp);