import { connect, useDispatch, useSelector } from "react-redux";
import { addHero, removeHero } from "../redux/avengers/actioncreators/avengers.action.creators";

let AvengersHookComp = ()=> {
    let numberOfAvengers = useSelector( (state)=> state.numberOfAvengers );
    let dispatch = useDispatch();
    return <div>
                <h1>Avengers with Hooks</h1>
                <h2>Number of Avengers : { numberOfAvengers }</h2>
                <button onClick={ ()=> dispatch( addHero() ) }>Add Avenger</button>
                <button onClick={ ()=> dispatch( removeHero() ) }>Remove Avenger</button>
            </div>
}

/* 
const mapStateToProps = (state) => {
    return {
        numberOfAvengers : state.numberOfAvengers
    }
}
const mapDispatchToProps = (dispatch) => {
    return {
        addHero : ()=> dispatch( addHero() ),
        removeHero : ()=> dispatch( removeHero() ),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(AvengersHookComp); 
*/
export default AvengersHookComp; 