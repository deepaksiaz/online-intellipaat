import { ADDHERO, REMOVEHERO } from "../actiontypes/avengers.types"

const addHero = ()=>{
    return {
        type : ADDHERO
    }
};
const removeHero = ()=>{
    return {
        type : REMOVEHERO
    }
};

export { addHero, removeHero };