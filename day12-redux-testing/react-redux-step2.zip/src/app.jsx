import { Component } from "react";
import { Provider } from "react-redux";
import AvengersComp from "./components/avengers";
import AvengersHookComp from "./components/avenger-hooks";
import store from "./redux/store"

class App extends Component{
    render(){
        return <div>
                    <h1>React and Redux Example</h1>
                    <Provider store={ store }>
                        <AvengersComp/>
                        <AvengersHookComp/>
                    </Provider>
               </div>
    }
}

export default App;