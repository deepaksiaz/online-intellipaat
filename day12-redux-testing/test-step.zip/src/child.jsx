import { useState } from "react";

function ChildComp() {
  let [power, setPower] = useState(0);
  let [uname, setUname] = useState('');
  let increasePower = () => {
    setPower(power+1);
  }
  return <div>
          <h1>welcome to your life</h1>
          <hr/>
          <h2>Power is : {power}</h2>
          <button onClick={ increasePower }>Increase Power</button>
          <br/>
          <h3>User Name is : { uname }</h3>
          <label htmlFor="uname">Set User Name : </label>
          <input value={ uname }  onChange={(evt)=> setUname(evt.target.value) } id="uname"/>
         </div>;
}

export default ChildComp;
