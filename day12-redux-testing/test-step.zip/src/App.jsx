import { Component } from "react";

class App extends Component{
  state = {
    title : "Batman"
  }
  render(){
    return <div>
        <h1>Welcome to your life</h1>
        <h2>{ this.state.title }</h2>
    </div>
  }
}

export default App;