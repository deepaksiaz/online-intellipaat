import { render, screen } from '@testing-library/react';
import ChildComp from './child';

describe("checking the component", function(){
  /* */ 
  test('welcome to your life', () => {
    render(<ChildComp />);
    const linkElement = screen.getByText(/welcome to your life/);
    expect(linkElement).toBeInTheDocument();
  });

  /*

  getAllBy will get a collection of matching elements
  getBy will get the only matching element if multiple matching elements found then we have an error


  // works on component created asynchronously
  findAllBy will get a collection of matching elements
  findBy will get the only matching element 



  queryAllBy will get a collection of matching elements
  queryBy will get the only matching element 
  */
  beforeAll(()=>{
    console.log("before all was called")
  })
  
  test("check for power", ()=>{
    render(<ChildComp/>);
    let powerHeading = screen.findByText("h1");
    // expect(powerHeading).toContainText("Power is : 0");
    console.log(powerHeading);
  })
  
})