import App from "./App";
describe("Testing App Component", function(){
    let app = null;
    beforeEach(()=>{
        app = new App();
    });

    test("should have a state called title",()=>{
        expect(app.state.title).toBeDefined();
    })
    test("title should be Batman",()=>{
        expect(app.state.title).toBe("Batman");
    })
})