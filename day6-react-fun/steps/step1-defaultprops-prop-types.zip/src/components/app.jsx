import { Component } from "react";
import HeroesComp from "./heroes";

class App extends Component{
    state = {
        avengers : ['Ironman','Hulk'],
        justiceleague : ['Batman','Superman','Aquaman'],
        indicheroes : ['Shaktiman'],
    }
    render(){
        return <div>
                    <h1>Hereos Application</h1>
                    <HeroesComp version={101} list={ this.state.avengers } title="Avengers" />
                    <HeroesComp version={102} list={ this.state.justiceleague } title="Justice League" />
                    <HeroesComp version={103} list={ this.state.indicheroes } title="Indic Heroes" />
                    <hr />
                    <HeroesComp title="App Title" version={ 101 } list={ this.state.avengers } />
                    <HeroesComp version={ 102 } list={ this.state.justiceleague } title="Justice League" />
                    <HeroesComp version={ 103 } list={ this.state.indicheroes } title="Indic Heroes" />
               </div>
    }
}

export default App;