import { Component } from "react";
// import "./app.style.css";

class App extends Component{
    render(){
        return <div className="container">
                   {/*  <h1 className="text-primary">Welcome to your life</h1>
                    <h1 className="text-danger">Welcome to your life</h1>
                    <h1 className="text-warning">Welcome to your life</h1>
                    <h1 className="text-info">Welcome to your life</h1>
                    <h1 className="text-secondary">Welcome to your life</h1> */}
                    {/*                     
                    username
                    userage
                    useremail
                    usercity 
                    */}
                <form method="post">
                    <div className="mb-3">
                        <label htmlFor="username" className="form-label">Your Name</label>
                        <input name="username" type="text" className="form-control" id="username"/>
                        <div className="text-danger">Enter your name</div>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="userage" className="form-label">Your Age</label>
                        <input name="userage" type="number" className="form-control" id="userage"/>
                        <div className="text-danger">Enter your age</div>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="usermail" className="form-label">Your eMail</label>
                        <input name="usermail" type="mail" className="form-control" id="userage"/>
                        <div className="text-danger">Enter your eMail</div>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="usercity" className="form-label">Your City</label>
                        <select name="usercity" className="form-select">
                            <option>Select Here</option>
                            <option value={"bangalore"}>Bangalore</option>
                            <option value={"chennai"}>Chennai</option>
                            <option value={"pune"}>Pune</option>
                            <option value={"delhi"}>Delhi</option>
                        </select>
                        <div className="text-danger">Enter your eMail</div>
                    </div>
                    <button type="submit" className="btn btn-primary">Register</button>
                </form>
                </div>
    }
}

export default App;