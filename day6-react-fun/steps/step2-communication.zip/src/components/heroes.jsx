import { Component } from "react";

class HeroesComp extends Component{
    render(){
        return <div>
                    <h2>Power is : { this.props.power }</h2>
                    <button onClick={()=> this.props.increaseHandler(Math.round( Math.random() * 100 )) }>Increase Power</button>
                </div>
    }
}

export default HeroesComp;